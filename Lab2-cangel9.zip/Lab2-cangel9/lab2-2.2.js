console.log('[Lab 2-2.2] Favicon experiment loaded.');
