console.log('[Lab 2-2.1] Background pattern page loaded.');
