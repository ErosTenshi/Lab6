const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

// === Sounds ===
const jumpSound = new Audio('jump.wav');
const coinSound = new Audio('coin.wav');
const hitSound = new Audio('hit.wav');

// === Sprites ===
const player = new Sprite(100, 320, 40, 40, 'orange');
const ground = new Sprite(0, 360, 800, 40, '#654321');
const coin = new Sprite(400, 310, 20, 20, 'gold');
const obstacle = new Sprite(600, 320, 30, 40, 'red');

let gravity = 0.5;
let velocityY = 0;
let jumping = false;
let score = 0;

// === Keyboard ===
window.addEventListener('keydown', e => {
  if (e.code === 'Space' && !jumping) {
    velocityY = -10;
    jumping = true;
    jumpSound.play().catch(() => {});
  }
});

function update() {
  velocityY += gravity;
  player.y += velocityY;

  // Land on ground
  if (player.y + player.height >= ground.y) {
    player.y = ground.y - player.height;
    velocityY = 0;
    jumping = false;
  }

  // Collision with coin
  if (player.collidesWith(coin) && coin.visible) {
    coin.visible = false;
    score += 10;
    coinSound.play().catch(() => {});
  }

  // Collision with obstacle
  if (player.collidesWith(obstacle)) {
    hitSound.play().catch(() => {});
    velocityY = -5; // small bounce back
  }
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ground.draw(ctx);
  coin.draw(ctx);
  obstacle.draw(ctx);
  player.draw(ctx);
  ctx.fillStyle = 'white';
  ctx.font = '20px Arial';
  ctx.fillText('Score: ' + score, 20, 30);
}

function loop() {
  update();
  draw();
  requestAnimationFrame(loop);
}

loop();
