$(document).ready(function() {
  $('#startBtn').click(function() {
    console.log('Animation started at', new Date().toLocaleTimeString());
    $('#box').css('left', '400px');

    setTimeout(function() {
      console.log('Animation ended at', new Date().toLocaleTimeString());
      $('#box').css('left', '0');
    }, 2500);
  });
});
