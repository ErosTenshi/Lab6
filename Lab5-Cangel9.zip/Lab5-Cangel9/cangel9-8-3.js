$(document).ready(function() {
  $('#jumpBtn').click(function() {
    let height = parseInt($('#height').val());
    let duration = parseInt($('#duration').val());

    console.log('Jump started | Height:', height, 'px | Duration:', duration, 'ms');

    $('#jumper').animate(
      { bottom: height + 'px' },
      {
        duration: duration / 2,
        easing: 'easeOutCubic',
        complete: function() {
          $('#jumper').animate(
            { bottom: '0px' },
            {
              duration: duration / 2,
              easing: 'easeInCubic',
              complete: function() {
                console.log('Jump ended at', new Date().toLocaleTimeString());
              }
            }
          );
        }
      }
    );
  });

  // Define custom easing functions
  $.easing.easeInCubic = function(x, t, b, c, d) {
    return c * (t /= d) * t * t + b;
  };
  $.easing.easeOutCubic = function(x, t, b, c, d) {
    return c * ((t = t/d - 1) * t * t + 1) + b;
  };
});
