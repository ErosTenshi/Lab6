(function(){
  const canvas = document.getElementById('gameCanvas');
  const ctx = canvas.getContext('2d');
  const sheet = new Image();
  sheet.src = '../images/spriteSheet.png';

  const FRAME_W = 75, FRAME_H = 100, FRAMES = 6;
  let frame = 0, last = 0;

  function draw(ts){
    if (ts - last > 100) { // ~10fps
      frame = (frame + 1) % FRAMES;
      last = ts;
    }
    ctx.clearRect(0,0,canvas.width,canvas.height);
    ctx.drawImage(sheet, frame*FRAME_W, 0, FRAME_W, FRAME_H, 100, 200, FRAME_W, FRAME_H);
    requestAnimationFrame(draw);
  }
  sheet.onload = () => requestAnimationFrame(draw);
})();