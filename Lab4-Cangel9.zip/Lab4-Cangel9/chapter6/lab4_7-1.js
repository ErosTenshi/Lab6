(function(){
  const canvas = document.getElementById('gameCanvas');
  const ctx = canvas.getContext('2d');
  const sheet = new Image();
  sheet.src = '../images/spriteSheet.png';
  sheet.onload = () => {
    // Draw the first frame (0,0 -> 75x100) onto canvas at (100,200)
    ctx.drawImage(sheet, 0, 0, 75, 100, 100, 200, 75, 100);
  };
})();