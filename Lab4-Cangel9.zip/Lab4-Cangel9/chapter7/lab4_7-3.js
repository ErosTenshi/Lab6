(function(){
  const canvas = document.getElementById('gameCanvas');
  const ctx = canvas.getContext('2d');
  const sheet = new Image();
  sheet.src = '../images/spriteSheet.png';

  const FRAME_W = 75, FRAME_H = 100, FRAMES = 6;
  const platforms = [{ left: 50, width: 300, top: 300, height: 10 }];
  const runner = { left: 100, width: FRAME_W, top: 200 };

  function onPlatform() {
    const cx = runner.left + runner.width/2;
    const p = platforms[0];
    return cx >= p.left && cx <= p.left + p.width;
  }

  let last = 0, frame = 0;
  function draw(ts){
    if (ts - last > 100) { // animate only when "on track"
      if (onPlatform()) frame = (frame + 1) % FRAMES;
      else frame = 0;
      last = ts;
    }
    ctx.clearRect(0,0,canvas.width,canvas.height);
    // platform
    ctx.fillStyle = '#666';
    for (const p of platforms) ctx.fillRect(p.left, p.top, p.width, p.height);
    // runner
    ctx.drawImage(sheet, frame*FRAME_W, 0, FRAME_W, FRAME_H, runner.left, runner.top, FRAME_W, FRAME_H);
    requestAnimationFrame(draw);
  }
  sheet.onload = () => requestAnimationFrame(draw);
})();