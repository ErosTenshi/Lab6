

function SnailBait() {
  this.paused = false;
  this.images = [];
  this.imageUrls = ['sprite.png'];
  this.imagesLoaded = 0;
}

SnailBait.prototype.togglePaused = function () {
  this.paused = !this.paused;

  if (this.paused) {
    this.stopAnimation();
    console.log("Paused");
  } else {
    this.startAnimation();
    console.log("Resumed");
    // this.lastAnimationFrameTime = window.performance.now();
  }
};

SnailBait.prototype.initializeImages = function () {
  var self = this;
  for (var i = 0; i < this.imageUrls.length; i++) {
    var image = new Image();
    image.src = this.imageUrls[i];
    image.onload = function () {
      self.imagesLoaded++;
      if (self.imagesLoaded === self.imageUrls.length) {
        self.startCountdown();
      }
    };
    this.images.push(image);
  }
};

SnailBait.prototype.startCountdown = function () {
  var self = this;
  var countdownElement = document.getElementById("countdown");
  var counter = 5;

  countdownElement.style.display = "block";
  countdownElement.innerHTML = counter;

  var interval = setInterval(function () {
    counter--;
    if (counter > 0) {
      countdownElement.innerHTML = counter;
    } else {
      countdownElement.innerHTML = "Go!";
      clearInterval(interval);
      setTimeout(function () {
        countdownElement.style.display = "none";
        self.startAnimation();
      }, 1000);
    }
  }, 1000);
};

SnailBait.prototype.startAnimation = function () {
  console.log("Game animation started");
};

SnailBait.prototype.stopAnimation = function () {
  console.log("Game animation stopped");
};

var snailBait = new SnailBait();
snailBait.initializeImages();
