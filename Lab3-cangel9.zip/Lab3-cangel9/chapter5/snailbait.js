
function fadeInElements(elements) {
  for (var i = 0; i < elements.length; i++) {
    elements[i].style.opacity = 1;
  }
}

function fadeOutElements(elements) {
  for (var i = 0; i < elements.length; i++) {
    elements[i].style.opacity = 0;
  }
}

console.log("Custom loading GIF integrated, fadeIn/fadeOut updated.");
